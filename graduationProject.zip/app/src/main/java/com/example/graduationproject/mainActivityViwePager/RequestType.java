package com.example.graduationproject.mainActivityViwePager;

public class RequestType {
    static final String ALL="all";
    static final String RECENT="recent";
    static final String RECOMMEND="recommend";
}
